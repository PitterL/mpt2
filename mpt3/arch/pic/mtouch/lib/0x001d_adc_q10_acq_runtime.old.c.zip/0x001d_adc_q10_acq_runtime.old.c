
/*============================================================================
Filename : 0x001d_qtm_q10_acq_runtime.c
Project : QTouch Modular Library
Purpose : Acquisition module - Q10 and compatible
------------------------------------------------------------------------------
Version Number : 1.0
Last Updated : 4/10/2022
Updated By : Pitter Liao
------------------------------------------------------------------------------
Copyright (c) 2022 Microchip. All rights reserved.
------------------------------------------------------------------------------
Revision 0.1 - Inlitialize
============================================================================*/

/* Include files */
#include "compiler.h"

/* Header file for internal declarations */
#include "adc_acq_q10_0x001b_api.h"


/*============================================================================
touch_ret_t adclib_init_acquisition_module(qtm_acquisition_control_t* acq_control_ptr)
------------------------------------------------------------------------------
Purpose: Initialize the ADC & Assign pins
Input  : pointer to acquisition set
Output : touch_ret_t: TOUCH_SUCCESS or INVALID_PARAM
Notes  : ptc_init_acquisition module must be called ONLY once with a pointer to each config set
============================================================================*/
touch_ret_t adclib_init_acquisition_module(/*qtm_acquisition_control_t*/ void* acq_control_ptr)
{
  touch_ret_t touch_return_param = TOUCH_SUCCESS;


  return touch_return_param
}


/*============================================================================
touch_ret_t adc_qtlib_assign_signal_memory(uint16_t* adc_signal_raw_data_ptr)
------------------------------------------------------------------------------
Purpose: Assign raw signals pointer to array defined in application code
Input  : pointer to raw data array
Output : touch_ret_t: TOUCH_SUCCESS or INVALID_POINTER
Notes  : none
============================================================================*/
touch_ret_t adclib_assign_signal_memory(uint16_t* adc_signal_raw_data_ptr)
{
  touch_ret_t touch_return_this = TOUCH_SUCCESS;

  return touch_return_this;
}

/*============================================================================
touch_ret_t adclib_enable_sensor_node(adc_acquisition_control_t* adc_acq_control_ptr, uint16_t qtm_which_node_number)
------------------------------------------------------------------------------
Purpose:  Enables a sensor node for measurement
Input  :  Node configurations pointer, node (channel) number
Output : touch_ret_t:
Notes  :
============================================================================*/
touch_ret_t adclib_enable_sensor_node(/*adc_acquisition_control_t*/void* adc_acq_control_ptr, uint8_t qtm_which_node_number)
{
  touch_ret_t node_enable_t_status = TOUCH_SUCCESS;
  adc_acquisition_control_t *acq_control_ptr = (adc_acquisition_control_t *)adc_acq_control_ptr;

  if(acq_control_ptr == NULL)
  {
    /* Not assigned */
    node_enable_t_status = TOUCH_INVALID_POINTER;
  }
  else if(qtm_which_node_number >= (acq_control_ptr->qtm_acq_node_group_config->num_channel_nodes))
  {
    node_enable_t_status = TOUCH_INVALID_INPUT_PARAM;
  }
  else
  {
    acq_control_ptr->qtm_acq_node_data[qtm_which_node_number].node_acq_status = NODE_ENABLED;
  }

  return node_enable_t_status;
}

/*============================================================================
touch_ret_t adclib_calibrate_sensor_node(qtm_acquisition_control_t* acq_control_ptr, uint16_t qtm_which_node_number)
------------------------------------------------------------------------------
Purpose:  Marks a sensor node for calibration
Input  :  Node configurations pointer, node (channel) number
Output : touch_ret_t:
Notes  :
============================================================================*/
touch_ret_t adclib_calibrate_sensor_node(/*qtm_acquisition_control_t*/void* adc_acq_control_ptr, uint16_t qtm_which_node_number)
{
  adc_acquisition_control_t *acq_control_ptr = (adc_acquisition_control_t *)adc_acq_control_ptr;
  uint8_t c_temp_calc = 0u;

  touch_ret_t node_calibrate_t_status = TOUCH_SUCCESS;
  if(acq_control_ptr == NULL)
  {
    /* Not assigned */
    node_calibrate_t_status = TOUCH_INVALID_POINTER;
  }
  else if(qtm_which_node_number >= (acq_control_ptr->qtm_acq_node_group_config->num_channel_nodes))
  {
    node_calibrate_t_status = TOUCH_INVALID_INPUT_PARAM;
  }
  else
  {
    c_temp_calc = acq_control_ptr->qtm_acq_node_group_config->acq_sensor_type;
    /* Self or mutual - to decide starting CCCAL */
    if(NODE_SELFCAP == c_temp_calc)
    {
      /* Initial CC Value */
      acq_control_ptr->qtm_acq_node_data[qtm_which_node_number].node_comp_caps = 0;
      /* CAL Flag */
      acq_control_ptr->qtm_acq_node_data[qtm_which_node_number].node_acq_status |= NODE_CAL_REQ;
    }
    else
    {
      node_calibrate_t_status = TOUCH_INVALID_INPUT_PARAM;
    }
  }
  return node_calibrate_t_status;
}
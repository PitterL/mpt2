/*============================================================================
Filename : mtm_acq_q10_0x001b.api.h
Project : MTouch Modular Library
Purpose : API for Acquisition module - Mtouch Selfcap
------------------------------------------------------------------------------
Version Number : 0.1
Last Updated : 04/09/2022
Updated By : Pitter.Liao
Revision 0.1: 
    Initialized the file
*/
------------------------------------------------------------------------------
Copyright (C) 2022 Micorchip. All rights reserved.
------------------------------------------------------------------------------
============================================================================*/

#ifndef TOUCH_API_Q10_ACQ_MODULE_H
#define TOUCH_API_Q10_ACQ_MODULE_H

#include <stdint.h>
#include "adc_common_components_api.h"

#define _AN_MSK(_n) ((_n)& 0x7))
#define _AN_GRP(_g) (((_n) & 7) << 3)
#define ANA(_n)  (_AN_GRP(0) | _AN_MSK(_n))
#define ANB(_n)  (_AN_GRP(1) | _AN_MSK(_n))
#define ANC(_n)  (_AN_GRP(2) | _AN_MSK(_n))
#define AND(_n)  (_AN_GRP(3) | _AN_MSK(_n))
#define ANE(_n)  (_AN_GRP(4) | _AN_MSK(_n))

#define TO_AN_PORT(_an)  (((_an) >> 3) & 0x7)
#define TO_AN_PIN(_an)  ((_an) & 0x7)

/*----------------------------------------------------------------------------
 * Structure Declarations
 *----------------------------------------------------------------------------*/

/* Node group configuration */
typedef struct adc_acq_node_group_config_type {
	uint8_t  num_channel_nodes;    /* Number of channel nodes actually */
	uint8_t  acq_sensor_type;     /* Self or mutual sensors */
	uint8_t  calib_option_select; /* Hardware tuning: XX | TT 3/4/5 Tau | X | XX None/RSEL/PRSC/CSD */
	uint8_t  freq_option_select;  /* SDS or ASDV setting */
} adc_acq_node_group_config_t;

/* Node configuration */
enum { NODE_SHIELD, NODE_SENSOR, NUM_NODE_TYPE };
typedef struct {
	uint8_t nodes[NUM_NODE_TYPE];        /* Selects sensor for this node */
	uint8_t  node_csd;          /* Charge Share Delay */
	uint8_t  node_rsel_prsc;    /* Bits 7:4 = Resistor, Bits 3:0  Prescaler */
	uint8_t  node_gain;         /* Bits 7:4 = Analog gain, Bits 3:0 = Digital gain */
	uint8_t  node_oversampling; /* Accumulator setting */
} adc_acq_node_config_t;


/* Node run-time data - Defined in common api as it will be used with all acquisition modules */

/* Container structure for sensor group */
typedef struct
{
  adc_acq_node_group_config_t* qtm_acq_node_group_config;
  adc_acq_node_config_t* qtm_acq_node_config;
  adc_acq_node_data_t* qtm_acq_node_data;
} adc_acquisition_control_t;

/*----------------------------------------------------------------------------
 * prototypes
 *----------------------------------------------------------------------------*/

/* Library prototypes */
/*============================================================================
touch_ret_t adclib_acquisition_process(void)
------------------------------------------------------------------------------
Purpose: Signal capture and processing
Input  : (Measured signals, config)
Output : TOUCH_SUCCESS or TOUCH_CAL_ERROR
Notes  : none
============================================================================*/
touch_ret_t adclib_acquisition_process(void);

/*============================================================================
touch_ret_t adclib_init_acquisition_module(adc_acquisition_control_t *adc_acq_control_ptr);
------------------------------------------------------------------------------
Purpose: Initialize the ADC & Assign pins
Input  : pointer to acquisition set
Output : touch_ret_t: TOUCH_SUCCESS or INVALID_PARAM
Notes  : adc_init_acquisition module must be called ONLY once with a pointer to each config set
============================================================================*/
touch_ret_t adclib_init_acquisition_module(/*adc_acquisition_control_t*/void *adc_acq_control_ptr);


/*============================================================================
touch_ret_t adclib_assign_signal_memory(uint16_t* adc_signal_raw_data_ptr)
------------------------------------------------------------------------------
Purpose: Assign raw signals pointer to array defined in application code
Input  : pointer to raw data array, autoscan data array 
Output : touch_ret_t: TOUCH_SUCCESS or INVALID_POINTER
Notes  : none
============================================================================*/
touch_ret_t adclib_assign_signal_memory(uint16_t* adc_signal_raw_data_ptr);

/*============================================================================
touch_ret_t adclib_enable_sensor_node(adc_acquisition_control_t* adc_acq_control_ptr, uint16_t qtm_which_node_number)
------------------------------------------------------------------------------
Purpose:  Enables a sensor node for measurement
Input  :  Node configurations pointer, node (channel) number
Output : touch_ret_t:
Notes  :
============================================================================*/
touch_ret_t adclib_enable_sensor_node(/*adc_acquisition_control_t*/void* adc_acq_control_ptr, uint8_t qtm_which_node_number);
#endif